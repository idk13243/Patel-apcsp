import SwiftUI

struct Song: Identifiable {
    let id = UUID()
    let title: String
    let artist: String
}

struct ContentView: View {
    
    let songs = [
        Song(title: "Song 1", artist: "Drake"),
        Song(title: "Song 2", artist: "Taylor Swift"),
        Song(title: "Song 3", artist: "Drake"),
        Song(title: "Song 4", artist: "The Weeknd"),
        Song(title: "Song 5", artist: "Taylor Swift"),
        Song(title: "Song 6", artist: "Bruno Mars"),
        Song(title: "Song 7", artist: "The Weeknd"),
        Song(title: "Song 8", artist: "Drake")
    ]
    
    @State private var shuffledSongs: [Song] = []
    
    var body: some View {
        VStack(spacing: 20) {
            Text("My Playlist")
                .font(.largeTitle)
                .bold()
            
            List(shuffledSongs) { song in
                VStack(alignment: .leading) {
                    Text(song.title)
                        .font(.headline)
                    
                    Text(song.artist)
                        .foregroundStyle(.secondary)
                }
            }
            
            Button("Shuffle Playlist") {
                shufflePlaylist()
            }
            .buttonStyle(.borderedProminent)
        }
        .padding()
        .onAppear {
            shufflePlaylist()
        }
    }
    
    func shufflePlaylist() {
        var remainingSongs = songs.shuffled()
        var newPlaylist: [Song] = []
        
        while !remainingSongs.isEmpty {
            let lastArtist = newPlaylist.last?.artist
            
            // Find songs whose artist is different from the last song
            let possibleSongs = remainingSongs.filter {
                $0.artist != lastArtist
            }
            
            if let nextSong = possibleSongs.randomElement() {
                newPlaylist.append(nextSong)
                
                // Remove the song we just played
                remainingSongs.removeAll {
                    $0.id == nextSong.id
                }
            } else {
                // If no valid song exists, use a random remaining song
                if let nextSong = remainingSongs.randomElement() {
                    newPlaylist.append(nextSong)
                    
                    remainingSongs.removeAll {
                        $0.id == nextSong.id
                    }
                }
            }
        }
        
        shuffledSongs = newPlaylist
    }
}

#Preview {
    ContentView()
}
